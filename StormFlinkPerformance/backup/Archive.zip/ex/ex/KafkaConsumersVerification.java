//package com.nventdata.task.flink;
//
//import com.nventdata.task.flink.ex.AvroConsumer;
//
///**
// * Created by kidio on 25/08/15.
// */
//public class KafkaConsumersVerification {
//    public static void main (String [] args) {
//        AvroConsumer consumer1 = new AvroConsumer();
//        consumer1.countMessage("random1");
//        System.out.println("random1: " + consumer1.getCount());
//
//
//        AvroConsumer consumer2 = new AvroConsumer();
//        consumer2.countMessage("random1");
//        System.out.println("random2: " + consumer2.getCount());
//
//
//        AvroConsumer consumer3 = new AvroConsumer();
//        consumer1.countMessage("random3");
//        System.out.println("random3: " + consumer3.getCount());
//
//    }
//}
